package com.example.demo.model;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface DangNhapMapper {
	
	

	@Select("SELECT COUNT(*) FROM dangnhap WHERE email=#{email} AND password=#{password}")
	boolean count(DangNhap dangnhap);

	@Insert("INSERT INTO dangnhap(email, password) " + " VALUES (#{email}, #{password})")
	int insert(DangKy dangky);

	@Select("SELECT COUNT(*) FROM dangnhap WHERE email=#{email} ")
	boolean countt(DangKy dangky);

}
