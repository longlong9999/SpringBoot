package com.example.demo.model;

public class Product {
	private String id;
	private String Name;
	private String Price;
	private String Quantity;
	private String Image;
	private String Status;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getPrice() {
		return Price;
	}
	public void setPrice(String price) {
		Price = price;
	}
	public String getQuantity() {
		return Quantity;
	}
	public void setQuantity(String quantity) {
		Quantity = quantity;
	}
	
	
	public String getImage() {
		return Image;
	}
	public void setImage(String image) {
		Image = image;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public Product() {
		super();
	}
	public Product(String id, String name, String price, String quantity, String image, String status) {
		super();
		this.id = id;
		Name = name;
		Price = price;
		Quantity = quantity;
		Image = image;
		Status = status;
	}
	
	
	
	

}
